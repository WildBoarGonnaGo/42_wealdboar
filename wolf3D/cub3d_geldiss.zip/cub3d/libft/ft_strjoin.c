/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: geldiss <geldiss@student.21-school.ru>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/05/03 08:48:30 by geldiss           #+#    #+#             */
/*   Updated: 2020/10/29 08:55:37 by geldiss          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strjoin(char const *s1, char const *s2)
{
	char	*new;
	size_t	len1;
	size_t	len2;
	size_t	i;

	i = 0;
	len1 = (s1) ? ft_strlen(s1) : 0;
	len2 = (s2) ? ft_strlen(s2) : 0;
	if (!s1 || !s2)
		return (NULL);
	if (!(new = (char*)malloc(sizeof(char) * (len1 + len2 + 1))))
		return (NULL);
	while (s1[i])
	{
		new[i] = s1[i];
		i++;
	}
	i = 0;
	while (s2[i])
	{
		new[len1 + i] = s2[i];
		i++;
	}
	new[len1 + i] = '\0';
	return (new);
}
