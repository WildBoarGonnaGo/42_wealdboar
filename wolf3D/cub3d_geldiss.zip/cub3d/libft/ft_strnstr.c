/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnstr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: geldiss <geldiss@student.21-school.ru>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/05/03 08:48:30 by geldiss           #+#    #+#             */
/*   Updated: 2020/10/29 08:55:37 by geldiss          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strnstr(const char *big, const char *little, int len)
{
	char	*h;
	int		little_len;
	int		j;
	int		i;

	h = (char *)big;
	if (!(little_len = ft_strlen(little)))
		return (h);
	if (ft_strlen(big) < little_len || len < little_len)
		return (NULL);
	i = 0;
	while (h[i] && i <= len - little_len)
	{
		j = 0;
		while (little[j] && little[j] == h[i + j])
			j++;
		if (j == little_len)
			return (&h[i]);
		i++;
	}
	return (NULL);
}
