/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: geldiss <geldiss@student.21-school.ru>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/05/03 08:48:30 by geldiss           #+#    #+#             */
/*   Updated: 2020/10/29 08:55:37 by geldiss          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char		*ft_strnchr(const char *s, int c)
{
	char *tmp;

	while (*s && (*s != c))
		s++;
	if (*s == c)
	{
		tmp = (char*)s;
		*tmp = '\0';
		s++;
		return ((char*)s);
	}
	else
		return (0);
}

int			clear_gnl(char *remainder, char **line)
{
	if (remainder || *line)
	{
		free(remainder);
		free(*line);
		remainder = NULL;
		*line = NULL;
	}
	return (-1);
}

char		*check_remainder(char **remainder, char **line)
{
	char	*p_n;

	p_n = NULL;
	if (*remainder)
	{
		if ((p_n = ft_strnchr(*remainder, '\n')))
		{
			*line = ft_strdup(*remainder);
			ft_strlcpy(*remainder, p_n, (ft_strlen(p_n) + 1));
		}
		else
		{
			*line = ft_strdup(*remainder);
			free(*remainder);
			*remainder = NULL;
		}
	}
	else
	{
		if (!(*line = (char*)malloc(sizeof(char) * 1)))
			return (NULL);
		**line = '\0';
	}
	return (p_n);
}

int			get_next_line(int fd, char **line)
{
	int			rd;
	char		*p_n;
	char		*tmp;
	char		buf[BUFFER_SIZE + 1];
	static char	*remainder = NULL;

	if (!line || (read(fd, buf, 0) < 0) || BUFFER_SIZE < 1)
		return (-1);
	p_n = check_remainder(&remainder, line);
	while (!p_n && *line != NULL && (rd = read(fd, buf, BUFFER_SIZE)) > 0)
	{
		buf[rd] = '\0';
		if ((p_n = ft_strnchr(buf, '\n')))
		{
			if (!(remainder = ft_strdup(p_n)))
				return (clear_gnl(remainder, line));
		}
		tmp = *line;
		*line = ft_strjoin(*line, buf);
		free(tmp);
	}
	if (*line == NULL || rd < 0)
		return (clear_gnl(remainder, line));
	return (rd || remainder) ? 1 : 0;
}
