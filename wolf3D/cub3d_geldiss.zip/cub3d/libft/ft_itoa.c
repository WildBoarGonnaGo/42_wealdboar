/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_itoa.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: geldiss <geldiss@student.21-school.ru>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/05/03 08:48:30 by geldiss           #+#    #+#             */
/*   Updated: 2020/10/29 08:52:28 by geldiss          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static int	ft_get_size(int n, int minus)
{
	int	count;

	count = 1;
	while (n /= 10)
		count++;
	return (count + minus);
}

char		*ft_itoa(int n)
{
	int		size;
	int		minus;
	char	*str;

	minus = (n < 0) ? 1 : 0;
	if (n == -2147483648)
		return (ft_strdup("-2147483648"));
	if (n < 0)
		n = -n;
	size = ft_get_size(n, minus);
	if (!(str = malloc(sizeof(char) * (size + 1))))
		return (NULL);
	str[size--] = '\0';
	while (size >= minus)
	{
		str[size--] = n % 10 + '0';
		n /= 10;
	}
	if (minus)
		str[0] = '-';
	return (str);
}
