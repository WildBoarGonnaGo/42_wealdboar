/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: geldiss <geldiss@student.21-school.ru>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/05/03 08:48:30 by geldiss           #+#    #+#             */
/*   Updated: 2020/10/29 08:55:37 by geldiss          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static size_t	ft_count_words(char const *s, char c)
{
	size_t		words;

	words = 0;
	while (*s)
	{
		while (*s == c)
			s++;
		if (*s)
		{
			words++;
			while (*s && *s != c)
				s++;
		}
	}
	return (words);
}

static	char	*ft_alloc_word(char const *s, char c)
{
	size_t		size;
	char		*word;

	size = 0;
	word = 0;
	while (s[size] && s[size] != c)
		size++;
	if (!(word = (char *)malloc(sizeof(char) * (size + 1))))
		return (NULL);
	ft_strlcpy(word, s, size + 1);
	return (word);
}

char			**ft_split(char const *s, char c)
{
	size_t		count;
	size_t		words;
	char		**array;

	count = -1;
	if (!s)
		return (NULL);
	words = ft_count_words(s, c);
	if (!(array = malloc(sizeof(char *) * (words + 1))))
		return (NULL);
	while (++count < words)
	{
		while (*s == c)
			s++;
		if (!(array[count] = ft_alloc_word(s, c)))
		{
			while (count > 0)
				free(array[count--]);
			free(array);
			return (NULL);
		}
		s += ft_strlen(array[count]);
	}
	array[count] = 0;
	return (array);
}
